package com.example.a2timezone;

// all import statement goes here
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class TimezoneViewController {

    @FXML
    private TextField cityTextField;

    private TimezoneController timezoneController;
    private SceneController sceneController;

    /**
     * Initializes the controller after the scene is set.
     */
    public void initialize() {
        timezoneController = new TimezoneController();
        // SceneController initialization moved to findCityInfo method
    }

    /**
     * Retrieves city information based on the user-entered city name.
     */
    @FXML
    public void findCityInfo() {
        String cityName = cityTextField.getText();
        try {
            // Initialize the SceneController
            sceneController = new SceneController((Stage) cityTextField.getScene().getWindow());

            // Get city information from the TimezoneController
            JsonArray cityInfoArray = timezoneController.getCityInfo(cityName).getAsJsonArray();
            if (cityInfoArray.size() > 0) {
                JsonObject cityInfo = cityInfoArray.get(0).getAsJsonObject();
                String cityInfoStr = new Gson().toJson(cityInfo);

                // Load the resultscene.fxml and set the result
                FXMLLoader loader = new FXMLLoader(getClass().getResource("resultscene.fxml"));
                Parent root = loader.load();
                ResultViewController resultViewController = loader.getController();
                resultViewController.setResult(cityInfoStr);
                resultViewController.setSceneController(sceneController);

                // Set the new scene
                Stage stage = (Stage) cityTextField.getScene().getWindow();
                stage.setScene(new Scene(root, 600, 400));
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
