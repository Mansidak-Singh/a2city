package com.example.a2timezone;

// all import statement goes here
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class ResultViewController {

    @FXML
    private Button backButton;

    @FXML
    private Label cityInfoLabel;

    @FXML
    private Label cityInfoHeading;

    private SceneController sceneController;

    /**
     * Sets the result information in the UI based on the provided JSON string.
     *
     * @param result The JSON string containing city information.
     */
    public void setResult(String result) {
        JsonObject jsonObject = JsonParser.parseString(result).getAsJsonObject();
        StringBuilder formattedJson = new StringBuilder();
        for (String key : jsonObject.keySet()) {
            formattedJson.append(key).append(": ").append(jsonObject.get(key).getAsString()).append("\n");
        }
        cityInfoLabel.setText(formattedJson.toString());
        // Uncomment the following line if you want to set a specific heading
        // cityInfoHeading.setText("City-Info");
    }

    /**
     * Sets the SceneController for navigation between scenes.
     *
     * @param sceneController The SceneController instance.
     */
    public void setSceneController(SceneController sceneController) {
        this.sceneController = sceneController;
    }

    @FXML
    void goBack(ActionEvent event) {
        sceneController.switchToPreviousScene();
    }
}
