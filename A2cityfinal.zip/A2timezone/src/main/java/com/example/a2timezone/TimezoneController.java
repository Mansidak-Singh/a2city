package com.example.a2timezone;

// all import statement goes here
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class TimezoneController {

    // API key for accessing the city information service
    private static final String API_KEY = "1SZCuKCPB9ZMfQwAML9rhu9OWCnWHg4g7aX1KvL5";

    // Base URL for the city information API
    private static final String API_URL = "https://api.api-ninjas.com/v1/city?name=";

    /**
     * Retrieves city information based on the provided city name.
     *
     * @param cityName The name of the city for which information is requested.
     * @return A JsonArray containing city details.
     * @throws IOException If an I/O error occurs during the HTTP request.
     * @throws InterruptedException If the HTTP request is interrupted.
     */
    public JsonArray getCityInfo(String cityName) throws IOException, InterruptedException {
        String url = API_URL + cityName;
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("X-Api-Key", API_KEY)
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println("Raw JSON response: " + response.body());
        return new Gson().fromJson(response.body(), JsonArray.class);
    }
}
