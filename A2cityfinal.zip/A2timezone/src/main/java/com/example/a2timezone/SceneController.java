package com.example.a2timezone;

// all import statement goes here
import javafx.scene.Scene;
import javafx.stage.Stage;

public class SceneController {

    private final Stage stage;
    private Scene previousScene;

    /**
     * Creates a SceneController for managing scene transitions.
     *
     * @param stage The primary stage of the JavaFX application.
     */
    public SceneController(Stage stage) {
        this.stage = stage;
    }

    /**
     * Switches to the specified scene.
     *
     * @param scene The new scene to display.
     */
    public void switchScene(Scene scene) {
        previousScene = stage.getScene();
        stage.setScene(scene);
    }

    /**
     * Switches back to the previous scene.
     */
    public void switchToPreviousScene() {
        stage.setScene(previousScene);
    }
}
