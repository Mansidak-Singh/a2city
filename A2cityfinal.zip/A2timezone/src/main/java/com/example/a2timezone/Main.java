package com.example.a2timezone;

// all import statement goes here
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws IOException {
        // To Ensure the path to the FXML file is correct
        Parent root = FXMLLoader.load(getClass().getResource("/com/example/a2timezone/main.fxml"));
        Scene scene = new Scene(root, 600, 419);

        // To Set the application icon (stage icon) to download.png
        Image appIcon = new Image(getClass().getResourceAsStream("/download.png"));
        primaryStage.getIcons().add(appIcon);

        // TO Add the CSS file to the scene
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());

        primaryStage.setTitle("City-Info");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
